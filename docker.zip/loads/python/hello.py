print "hello world"
